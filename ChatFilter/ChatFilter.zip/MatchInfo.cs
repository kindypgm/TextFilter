using System;

namespace TextValidator
{
	internal struct MatchInfo
	{
		public Int32	matchCount	{ get; set; }
		public ChatType	chatType	{ get; set; }
	}
}